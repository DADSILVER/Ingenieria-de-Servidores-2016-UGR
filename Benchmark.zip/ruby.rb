
#DavCasSal
t_ini = Time.now

File.open('numeros.txt', 'r') do |f1|
  while linea = f1.gets
  end
end

t_fin = Time.now
t_total = (t_fin - t_ini) * 1000
puts t_total.to_s + ' milisegundos en Ruby'
