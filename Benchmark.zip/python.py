#DavCasSal

from time import time


t_ini = time()
infile = open('numeros.txt', 'r')


for linea in infile:
	linea    

infile.close()

t_fin = time()
t_total = (t_fin - t_ini) * 1000
print t_total , " milisegundos en Python"
