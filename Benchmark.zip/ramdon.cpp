//#DavCasSal

#include <stdlib.h>
#include <time.h>
#include<iostream>
#include <fstream>

using namespace std;
 
int main()
{
    int tam;
    cout<<"Introduce el Nº de numeros que quieres en el fichero: "<<endl;
    cin>>tam;

    ofstream fs("numeros.txt");
    int num, c;
    srand(time(NULL));
    
    for(c = 1; c <= tam; c++)
    {
        num = 1 + rand() % (11 - 1);
        fs << num<< endl;
    }

    fs.close();
    
    return 0;
}

