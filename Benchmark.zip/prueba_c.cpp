//#DavCasSal

#include <iostream>
#include <fstream>
#include <string>
#include <time.h>
#include <sys/time.h>

using namespace std;


double timeval_diff(struct timeval *a, struct timeval *b){

	return ((double)(a->tv_sec + (double) a-> tv_usec/1000000) - (double)(b->tv_sec + 	(double) b->tv_usec/1000000));
}


int main() {

   struct timeval t_ini, t_fin;
   double secs;
   string s;
   char texto[200];
   gettimeofday(&t_ini, NULL);

   fstream entrada;

   entrada.open("numeros.txt", ios::in);
   entrada >> texto;
   
   while(!entrada.eof()) {
      entrada >> texto;  
   }

   entrada.close();
   gettimeofday(&t_fin, NULL);

   secs = timeval_diff(&t_fin, &t_ini);
   printf("%.16g milisegundos en c++\n", secs * 1000.0);

   return 0;
}

